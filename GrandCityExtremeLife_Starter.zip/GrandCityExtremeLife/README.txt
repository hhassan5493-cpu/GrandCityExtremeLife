GRAND CITY: EXTREME LIFE — BROWSER PROTOTYPE

This is a small original 3D open-world prototype, not GTA V and not a complete GTA-scale game.

FILES
- index.html: game page and interface
- style.css: screen layout and mobile controls
- game.js: Three.js 3D scene, city, character, car and controls

HOW TO RUN
1. Keep all three files in the same folder.
2. Open the folder in a code editor.
3. Run it using a local web server (recommended), for example VS Code + Live Server.
4. Internet access is required because Three.js is loaded from jsDelivr CDN.
5. Open the local server address in Chrome on Android or on a PC.

CONTROLS
PC:
- WASD or arrow keys: move
- Shift: run
- E: enter/exit car

Touchscreen:
- Left joystick: move / steer
- RUN: run
- ENTER CAR: enter/exit the car

CURRENT FEATURES
- Small procedural 3D city
- Third-person player movement
- Follow camera
- Simple sports car driving
- Touch controls
- Basic mission text and HUD

NEXT DEVELOPMENT STEPS
- Add real 3D models and animations
- Add collision and road navigation
- Add traffic and pedestrian AI
- Add missions, police, combat and saving
- Port the project to Unity for a native Android APK

This prototype is intentionally lightweight. It does not yet include multiplayer, weapons, police AI, or a full story campaign.
