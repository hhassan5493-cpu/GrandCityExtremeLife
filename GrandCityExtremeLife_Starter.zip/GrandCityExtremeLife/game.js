import * as THREE from "three";

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87b8d8);
scene.fog = new THREE.Fog(0x87b8d8, 55, 190);

const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 350);
const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "low-power" });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = false;
document.getElementById("game").prepend(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xd9edff, 0x526044, 2.0);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe2b0, 2.0);
sun.position.set(-35, 70, 25);
scene.add(sun);

const mat = (color, roughness=1) => new THREE.MeshStandardMaterial({ color, roughness });
const groundMat = mat(0x647b54), roadMat = mat(0x30343a), lineMat = mat(0xe9dfb0);
const buildingMats = [0x8c9aa4,0xb3a18a,0x6e7d89,0xc0b8a6,0x777f86].map(c=>mat(c));
const carPaint = mat(0xd52d25, .55);
const dark = mat(0x18212a), glass = new THREE.MeshStandardMaterial({color:0x7fa9bd, roughness:.25, metalness:.15});
const white = mat(0xffffff), skin = mat(0xd5a078), shirt = mat(0x245b9a);

const box = (w,h,d, material, x,y,z, parent=scene) => {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), material);
  m.position.set(x,y,z); parent.add(m); return m;
};

// Ground and a compact grid-based city.
box(220,.5,220,groundMat,0,-.35,0);
for (let i=-3;i<=3;i++) {
  const p=i*24;
  box(8,.08,210,roadMat,p,.02,0);
  box(210,.08,8,roadMat,0,.025,p);
  for(let k=-4;k<=4;k++){
    box(.18,.025,3,lineMat,p,.08,k*24+9);
    box(3,.025,.18,lineMat,k*24+9,.08,p);
  }
}
const buildings=[];
for(let gx=-4;gx<=4;gx++){
  for(let gz=-4;gz<=4;gz++){
    if(Math.abs(gx)%2===0 && Math.abs(gz)%2===0) continue;
    const x=gx*24+(Math.random()-.5)*5, z=gz*24+(Math.random()-.5)*5;
    const w=9+Math.random()*5, d=9+Math.random()*5, h=8+Math.random()*27;
    const b=box(w,h,d,buildingMats[Math.floor(Math.random()*buildingMats.length)],x,h/2,z);
    buildings.push(b);
    // Simple repeated window strips.
    for(let y=3;y<h-2;y+=3.5){
      for(let xx=-w/2+1.2;xx<w/2-1;xx+=2.4){
        box(.9,1.1,.08,glass,x+xx,y,z+d/2+.05);
        box(.9,1.1,.08,glass,x+xx,y,z-d/2-.05);
      }
    }
  }
}

// Decorative trees.
const trunkMat=mat(0x65452c), leafMat=mat(0x286b3c);
for(let i=0;i<45;i++){
  const x=(Math.random()-.5)*190, z=(Math.random()-.5)*190;
  if(Math.abs(x%24)<6 || Math.abs(z%24)<6) continue;
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.35,2,6),trunkMat);
  trunk.position.set(x,1,z); scene.add(trunk);
  const crown=new THREE.Mesh(new THREE.SphereGeometry(1.5,7,6),leafMat);
  crown.position.set(x,3,z); scene.add(crown);
}

// Player model.
const player = new THREE.Group();
const body=box(.8,1.2,.45,shirt,0,1.35,0,player);
const head=new THREE.Mesh(new THREE.SphereGeometry(.32,10,8),skin);
head.position.set(0,2.15,0); player.add(head);
const legL=box(.25,.75,.28,dark,-.22,.45,0,player);
const legR=box(.25,.75,.28,dark,.22,.45,0,player);
player.position.set(0,0,0); scene.add(player);

// Sports car, made from simple geometry.
const car=new THREE.Group();
box(2.1,.65,4,carPaint,0,.75,0,car);
box(1.65,.75,1.8,glass,0,1.35,-.25,car);
for(const x of [-1.08,1.08]) for(const z of [-1.25,1.25]){
  const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.22,12),dark);
  wheel.rotation.z=Math.PI/2; wheel.position.set(x,.4,z); car.add(wheel);
}
car.position.set(8,0,5); scene.add(car);

let driving=false, cash=500, wanted=0;
const keys={}; let joy={x:0,y:0}, running=false;
let speed=0, carYaw=0;
const clock=new THREE.Clock();

addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true; if(e.key.toLowerCase()==="e") toggleCar();});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);

function toast(msg){
  const el=document.getElementById("toast"); el.textContent=msg; el.classList.add("show");
  clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.remove("show"),1800);
}
function toggleCar(){
  if(!driving && player.position.distanceTo(car.position)<4.5){
    driving=true; player.visible=false; toast("You entered the sports car!");
    document.getElementById("missionText").textContent="Drive around the city.";
    document.getElementById("carBtn").textContent="EXIT CAR";
  } else if(driving){
    driving=false; player.visible=true;
    player.position.set(car.position.x+2.5,0,car.position.z);
    toast("You exited the car.");
    document.getElementById("carBtn").textContent="ENTER CAR";
  } else toast("Move closer to the red sports car.");
}
document.getElementById("carBtn").addEventListener("click",toggleCar);
document.getElementById("runBtn").addEventListener("touchstart",e=>{e.preventDefault();running=true;});
document.getElementById("runBtn").addEventListener("touchend",()=>running=false);
document.getElementById("runBtn").addEventListener("mousedown",()=>running=true);
document.getElementById("runBtn").addEventListener("mouseup",()=>running=false);

// Mobile joystick.
const joyEl=document.getElementById("joystick"), stick=document.getElementById("stick");
let joyPointer=null;
joyEl.addEventListener("pointerdown",e=>{joyPointer=e.pointerId; joyEl.setPointerCapture(joyPointer); updateJoy(e);});
joyEl.addEventListener("pointermove",e=>{if(e.pointerId===joyPointer)updateJoy(e);});
function resetJoy(){joy={x:0,y:0};stick.style.transform="translate(0px,0px)";joyPointer=null;}
joyEl.addEventListener("pointerup",resetJoy); joyEl.addEventListener("pointercancel",resetJoy);
function updateJoy(e){
  const r=joyEl.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
  let dx=e.clientX-cx, dy=e.clientY-cy, len=Math.hypot(dx,dy), max=35;
  if(len>max){dx=dx/len*max;dy=dy/len*max;}
  joy={x:dx/max,y:dy/max}; stick.style.transform=`translate(${dx}px,${dy}px)`;
}
document.getElementById("startBtn").addEventListener("click",()=>{
  document.getElementById("startScreen").style.display="none";
  toast("Welcome to Grand City!");
});

function update(dt){
  const forward=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0)-joy.y;
  const side=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0)+joy.x;
  if(driving){
    const accel=forward;
    speed += accel*dt*16;
    speed *= Math.pow(.985,dt*60);
    speed=THREE.MathUtils.clamp(speed,-8,22);
    carYaw -= side*dt*1.8*(Math.abs(speed)/10+.2);
    car.rotation.y=carYaw;
    car.position.x += Math.sin(carYaw)*speed*dt;
    car.position.z += Math.cos(carYaw)*speed*dt;
    if(Math.abs(speed)>1) document.getElementById("missionText").textContent="Drive around the city. Speed: "+Math.round(Math.abs(speed)*5)+" km/h";
  } else {
    const moveSpeed=(running||keys.shift?9:5)*dt;
    const dir=new THREE.Vector3(side,0,forward);
    if(dir.length()>1)dir.normalize();
    player.position.x+=dir.x*moveSpeed;
    player.position.z+=dir.z*moveSpeed;
    if(dir.length()>.05) player.rotation.y=Math.atan2(dir.x,dir.z);
    legL.rotation.x=Math.sin(performance.now()*.012)*.35*dir.length();
    legR.rotation.x=-legL.rotation.x;
  }
  // Keep player and car inside the playable district.
  const actor=driving?car:player;
  actor.position.x=THREE.MathUtils.clamp(actor.position.x,-100,100);
  actor.position.z=THREE.MathUtils.clamp(actor.position.z,-100,100);
  // Follow camera.
  const yaw=driving?carYaw:player.rotation.y;
  const target=actor.position.clone().add(new THREE.Vector3(0,2.2,0));
  const behind=new THREE.Vector3(-Math.sin(yaw)*8,5.2,-Math.cos(yaw)*8);
  camera.position.lerp(target.clone().add(behind),1-Math.pow(.001,dt));
  camera.lookAt(target);
  if(!driving && player.position.distanceTo(car.position)<4.5){
    document.getElementById("missionText").textContent="Press E or ENTER CAR to drive.";
  }
}

function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.04);
  update(dt);
  renderer.render(scene,camera);
}
camera.position.set(0,6,-9); camera.lookAt(0,1,0);
animate();

addEventListener("resize",()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
});
